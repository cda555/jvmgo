# [《自己动手写Java虚拟机》][jd] 源代码

![jvm.go Logo][logo]

* [✎ 勘误表](v1/errata.md)
* [☺ 购买][jd]

[logo]: https://raw.githubusercontent.com/zxh0/jvmgo-book/master/v1/gophers/cover.png
[jd]: https://item.jd.com/11935272.html
