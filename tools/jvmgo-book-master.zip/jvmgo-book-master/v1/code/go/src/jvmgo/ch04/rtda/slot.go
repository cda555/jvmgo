package rtda

type Slot struct {
	num int32
	ref *Object
}
