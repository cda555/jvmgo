package rtda

type Object struct {
	// todo
}
